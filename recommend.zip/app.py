# -*- coding: utf-8 -*-
"""
Created on Wed Dec  8 23:48:44 2021

@author: barsuraj1
"""

import numpy as np
import pandas as pd
from flask import Flask, request, render_template

app = Flask(__name__)

rules = pd.read_csv(r"C:\Users\barsuraj1\Desktop\Product Recommendation\rules_tab.csv")
product = pd.read_csv(r"C:\Users\barsuraj1\Desktop\Product Recommendation\products_tab.csv")

rules.columns
rules.set_index(['Unnamed: 0'], inplace = True)


product.columns
product.set_index(['StockCode'], inplace = True)
 

def predict1(antecedent, rules, max_results= 6):
    
    # get the rules for this antecedent
    preds = rules[rules['antecedents'] == antecedent]
    
    # a messy way to convert a frozen set with one element to string
    preds = preds['consequents'].apply(iter).apply(next)
    
    return preds[:max_results].reset_index(drop=True)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    inputID = request.form['product_ID']
    preds = predict1({inputID}, rules)
    a_list = []
    
    # Display the descriptions of the predictions
    for stockid in preds:  
        a_list.append(product(stockid))
    
    #for i in preds:
       # a_list.append(product(i))
    
    return render_template('index.html', segment1 = a_list)


if __name__ == "__main__":
    app.run(debug=True)